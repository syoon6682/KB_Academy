package we.pet.test;



import java.sql.Date;

import we.pet.dao.CustDAO;
import we.pet.dao.CustDAOImpl;
import we.pet.vo.Cart;
import we.pet.vo.Customer;

public class Test {

	public static void main(String[] args) throws Exception {
		//CustDAO dao = new CustDAO("127.0.0.1");
		CustDAOImpl dao = new CustDAOImpl("127.0.0.1");
		//dao.addCustomer(new Customer("Tomas", "567-47-0915", "Texas" ,"010-5555-5555" , 50000.00));
		//dao.deleteCustomer(1);
		//dao.updateCustomer(new Customer(1, "Tomas", "567-47-0915", "Texas" ,"010-5555-5555" , 50000.00));
		//dao.getAllCustomers();
		
		//dao.getAllPet(8);
		//dao.getPet(3);
		//dao.getAllPetFoods();
		//dao.getAllOrders();
		
		//dao.getCustomer(1);
		//dao.getOrder(1);
//		System.out.println(dao.getPet(3));
		
		//dao.getPetFood(1234);
		dao.updateCart(new Cart(12, 1 , Date.valueOf("2022-12-03"), 12, 1));
		

	}

}
