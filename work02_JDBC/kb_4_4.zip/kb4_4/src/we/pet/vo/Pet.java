package we.pet.vo;

public class Pet {

	protected int id;
	protected String name;
	protected int age;
	protected boolean sex;

	
	public Pet(int id, String name, int age, boolean sex) {
		super();
		this.id = id;
		this.name = name;
		this.age = age;
		this.sex = sex;
	
	}

	
	
	public Pet() {}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public boolean isSex() {
		return sex;
	}
	public void setSex(boolean sex) {
		this.sex = sex;
	}

	@Override
	public String toString() {
		return "Pet [id=" + id + ", name=" + name + ", age=" + age + ", sex=" + sex + "]";
	}



	public int getSpecies() {
		// TODO Auto-generated method stub
		return 0;
	}



	public boolean isKidney() {
		// TODO Auto-generated method stub
		return false;
	}



	public boolean isWalktime() {
		// TODO Auto-generated method stub
		return false;
	}
	
	
	
	
}
